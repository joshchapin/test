package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    public void backButton(View view)
    {
        finish();
    }

    public void levelUp(View view)
    {
        String upgradeText = "You bought 1 ";
        LayoutInflater inflater = getLayoutInflater();
        //get the view from the xml file to use as the visual part of the notification
        View toastLayout = inflater.inflate(R.layout.popup_window,null);
        //Gets what text object to put the string onto
        TextView header = toastLayout.findViewById(R.id.Pop_upText);
        switch (view.getId())
        {
            case(R.id.jobLevel):
                upgradeText = upgradeText.concat(getString(R.string.Job1));
                break;
            case(R.id.jobLevel2):
                upgradeText = upgradeText.concat(getString(R.string.Job2));
                break;
            case(R.id.jobLevel3):
                upgradeText = upgradeText.concat(getString(R.string.Job3));
                break;
            case(R.id.jobLevel4):
                upgradeText = upgradeText.concat(getString(R.string.Job4));
                break;
            case(R.id.jobLevel5):
                upgradeText =  upgradeText.concat(getString(R.string.Job5));
                break;

                default:
                    upgradeText =   upgradeText.concat("error");
        }


        header.setText(upgradeText);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.BOTTOM, 0, 0);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
}
